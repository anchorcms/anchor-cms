<?php

return array(

    'menu'        => 'Menu',
    'edit_menu' => 'Sunting menu'

);
