<?php

return array(

    'panel' => 'Papan Administrasi',
    'title' => 'Selamat datang di situs Anchor Anda!',
    'message' => 'Di sini Anda akan menemukan semua alat yang Anda butuhkan untuk membuat konten situs Anda, manajemen pengguna, pos, dan halaman. Untuk informasi lebih lanjut mengenai apa yang dapat Anda lakukan dengan Anchor, silakan lihat dokumentasi kami di <a href="https://anchorcms.com/docs" target="_blank">http://anchorcms.com/docs</a>.',
    
);
